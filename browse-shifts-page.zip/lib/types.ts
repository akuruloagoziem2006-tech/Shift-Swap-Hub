export type Shift = {
  id: string
  user_id: string
  title: string
  description: string | null
  shift_date: string
  start_time: string
  end_time: string
  location: string
  role_type: string
  pay_rate: number | null
  shift_type: 'swap' | 'cover' | 'pickup'
  status: 'open' | 'pending' | 'closed'
  ai_match_score: number | null
  created_at: string
  updated_at: string
}

export type Profile = {
  id: string
  email: string | null
  full_name: string | null
  avatar_url: string | null
  job_role: string | null
  location: string | null
  preferred_days: string[] | null
  hourly_rate: number | null
  bio: string | null
  created_at: string
  updated_at: string
}

export type SwapRequest = {
  id: string
  shift_id: string
  requester_id: string
  message: string | null
  status: 'pending' | 'approved' | 'rejected'
  created_at: string
  updated_at: string
}

export type ShiftWithProfile = Shift & {
  profiles?: Profile
}
